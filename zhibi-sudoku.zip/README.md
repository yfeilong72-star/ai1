# 纸笔数独 · 安卓 APK 打包说明

这个工程把数独网页装进一个安卓应用里，完全离线可玩。你不需要安装任何开发工具，让 GitHub 在网上帮你打包即可。

## 第一步：注册并新建仓库

1. 登录 github.com，点右上角 **+**，选 **New repository**。
2. **Repository name** 随便填，例如 `zhibi-sudoku`。
3. 选 **Public**（公开仓库打包免费且不限时长；选 Private 也行，免费账号每月有额度）。
4. 其他都不用勾，点 **Create repository**。

## 第二步：上传工程文件

1. 把本压缩包解压到电脑上。
2. 在新仓库页面点 **uploading an existing file**（页面中间的蓝色链接）。
3. 打开解压后的文件夹，**选中里面的所有文件和文件夹**（`app`、`github-workflow`、`build.gradle`、`settings.gradle`、`gradle.properties`、`README.md` 等），整体拖进浏览器页面。注意拖的是文件夹里面的内容，不是外面那一层文件夹。
4. 等文件列表出现后，滚到页面底部，点绿色的 **Commit changes**。

## 第三步：确认打包配置已上传

打包配置在一个以点开头的隐藏文件夹 `.github` 里，有的电脑拖拽时会漏掉它。上传完成后检查仓库首页：

- 如果能看到 `.github` 文件夹，直接做第四步。
- 如果看不到，手动补一个：
  1. 点 **Add file → Create new file**。
  2. 在文件名框里输入 `.github/workflows/build.yml`（输入斜杠会自动变成文件夹）。
  3. 打开已上传的 `github-workflow/build.yml`，复制全部内容，粘贴到编辑框。
  4. 点 **Commit changes**。

## 第四步：等待打包并下载 APK

1. 点仓库顶部的 **Actions** 标签。第一次可能会提示启用工作流，点绿色按钮同意即可。
2. 你会看到一条名为 **Build APK** 的运行记录，黄色圆点表示正在打包，大约需要 3 到 6 分钟。
3. 变成绿色对勾后，点进这条记录，滚到页面底部的 **Artifacts**，点 `zhibi-sudoku-apk` 下载。
4. 下载的是一个 zip，解压后得到 `app-debug.apk`。

如果没有自动开始：在 Actions 页面左侧点 **Build APK**，再点右边的 **Run workflow**。

## 第五步：安装到手机

1. 把 `app-debug.apk` 传到手机（微信文件传输助手、数据线、网盘都行）。
2. 在手机上点开它，系统会提示"不允许安装未知来源应用"，按提示进入设置，允许当前使用的应用（文件管理器或微信）安装应用。
3. 返回后点"安装"。桌面上会出现"纸笔数独"。

要求安卓 8.0 及以上。这个 APK 是调试签名，自己安装使用没有问题，但不能上架应用商店。

## 打包失败怎么办

在 Actions 里点红色叉的那条记录，点 **Build debug APK** 展开日志，把最后几十行报错复制发给我，我来改。

## 想改应用内容

游戏本身是 `app/src/main/assets/index.html`，应用名在 `app/src/main/res/values/strings.xml`。在 GitHub 网页上点文件、点右上角铅笔图标即可修改，提交后会自动重新打包。
