package com.zhibi.sudoku;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private static final String PREFS = "zhibi";
    private WebView web;

    /** Paints the status bar, navigation bar and WebView background to match the page theme. */
    private void applyBars(int bg, boolean lightBars) {
        Window w = getWindow();
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(bg);
        View decor = w.getDecorView();
        int flags = decor.getSystemUiVisibility();
        if (lightBars) {
            flags = flags | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        } else {
            flags = flags & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        decor.setSystemUiVisibility(flags);
        if (web != null) {
            web.setBackgroundColor(bg);
        }
    }

    /** Called from the page (window.ZhiBi.setBars) whenever the player picks a theme. */
    public class Bridge {
        @JavascriptInterface
        public void setBars(String hex, boolean light) {
            int parsed;
            try {
                parsed = Color.parseColor(hex);
            } catch (Exception e) {
                return;
            }
            final int color = parsed;
            final boolean lightBars = light;
            getSharedPreferences(PREFS, MODE_PRIVATE)
                    .edit().putInt("bg", color).putBoolean("light", lightBars).apply();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    applyBars(color, lightBars);
                }
            });
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        boolean night = (getResources().getConfiguration().uiMode
                & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        web.setBackgroundColor(Color.parseColor(night ? "#0E131A" : "#E3EEF4"));
        setContentView(web);

        SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (sp.contains("bg")) {
            applyBars(sp.getInt("bg", Color.WHITE), sp.getBoolean("light", true));
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // lets the game save its progress
        s.setAllowFileAccess(false);           // assets are still readable
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Bridge(), "ZhiBi");
        web.setWebViewClient(new WebViewClient());

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
